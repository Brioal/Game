package com.brioal.utool;

import java.util.Scanner;

/**
 * Created by null on 15-11-14.
 */
class Node{
    public int score;
    public int Alpha=0;
    public int Beta=200000;
    int min;
    public Node son;
    public Node father;
    public Node brother;
    public int x,y;
    public  int deep=0;
    public static int[][] board;
    public Node(){min=-1;}
    public Node(int i,int j){x=i;y=j;}
    public static void initial(int[][] mind){
        board=new int[19][19];
        for(int i=0;i<19;i++)
            for(int j=0;j<19;j++)
                board[i][j]=mind[i][j];
        //��ʼɨ����
        int x_start=19;
        int x_stop=0;
        int y_start=19;
        int y_stop=0;
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                if(board[i][j]==10)board[i][j]=0;
                if (board[i][j] != 0) {
                    if (j < x_start) {
                        x_start = j;    // x_start����ȡ��С
                    }
                    if (x_stop < j) {
                        x_stop = j;  // s_stop����ȡ��
                    }
                    if (y_start > i) {
                        y_start = i;  //y_start ����ȡСֵ
                    }
                    if (y_stop < i) {
                        y_stop = i;  // y_stop����ȡ��ֵ
                    }

                }
            }
        }
        if(y_start!=0) y_start-=1;
        if(y_stop!=18)y_stop+=1;
        if(x_start!=0)x_start-=1;
        if(x_stop!=18)x_stop+=1;
        //���
        for(int i=y_start;i<=y_stop;i++)
            for(int j=x_start;j<=x_stop;j++)
            {
                if(board[i][j]==-1||board[i][j]==1)
                    continue;
                board[i][j]=10;
            }

    }

}

public class Calculate {
    private int[][] datas = new int[20][20];

    private int state_color;//1Ϊ���壬-1Ϊ���壬0Ϊ�Թ���


    public Calculate(int state_color) {
        this.state_color = state_color;
        for (int i = 0; i < datas.length; i++) {
            for (int j = 0; j < datas[0].length; j++) {
                datas[i][j] = 0;
            }
        }


    }

    public void addPoint(Point point) {
        int x = point.getX();
        int y = point.getY();
        System.out.println("add data to datas" + x + ":" + y);
        if (point.getState() == Point.STATE_BLACK) {

            datas[x][y] = 1 ;

        } else {
            datas[x][y] = -1 ;

        }


    }

    public Point getNext() {
        Point result = null;
        Node node = new Node();
        Node.initial(datas);
        AlphaBeta(node);
        Node n1;
        int max = 0;
        n1 = node.son;
        int x = 0;
        int y = 0;
        while (n1 != null) {
            System.out.println(n1.score);
            if (max < n1.score) {
                max = n1.score;
                x = n1.x;
                y = n1.y;

            }
            n1 = n1.brother;
            System.out.println("n1");
        }
        result = new Point(x, y);
        addPoint(result);
        return result;
    }


    public int Evaluation(int[][]mind) {
        int value = 0;
        int countm = 0;
        int county = 0;
        int space = 0;
        int[] six;
        six = new int[6];
        //�з���ɨ��
        for (int i = 0; i < 19; i++) {
            for (int j = 0; j < 14; j++) {
                for (int k = 0; k < 6; k++) {
                    if (mind[i][j + k] == 0 || mind[i][j + k] == 10) space++;
                    if (mind[i][j + k] == state_color) countm++;
                    if (mind[i][j + k] == -state_color) county++;
                    six[k] = mind[i][j + k];
                }

                if (space == 5) continue;
                if (countm > 1 && county > 1) continue;

                switch (countm) {
                    case 5:
                        value += 100000;
                        break;
                    case 4:
                        if (six[0] == -state_color) {
                            if (six[5] == 0 || six[5] == 10 || six[3] == 0 || six[3] == 10 || six[2] == 0 || six[2] == 10 || six[4] == 0 || six[4] == 10)
                                value += 720;

                        } else if (six[5] == -state_color) value += 720;
                        else if (six[0] == six[5] && six[5] == state_color) value += 4320;
                        break;
                    case 3:
                        if (county == 0 && six[1] == six[2] && six[2] == six[3] && six[3] == state_color) value += 720;
                        if (county == 0 && six[2] == six[3] && six[3] == six[4] && six[4] == state_color) value += 720;
                        else if (county == 0 && six[1] == six[2] && six[2] == six[4] && six[4] == state_color)
                            value += 720;
                        else if (county == 0 && six[1] == six[3] && six[3] == six[4] && six[4] == state_color)
                            value += 720;
                        break;
                    case 2:
                        if (county == 0 && six[2] == six[3] && six[3] == state_color) value += 120;
                        else if (county == 0 && six[2] == six[4] && six[4] == state_color) value += 120;
                        else if (county == 0 && six[1] == six[3] && six[3] == state_color) value += 120;
                        break;
                    case 1:
                        if (county == 0 && six[3] == state_color) value += 20;
                        if (county == 0 && six[2] == state_color) value += 20;

                }
                //�Է�����

                switch (county) {
                    case 5:
                        value -= 100000;
                        break;
                    case 4:
                        if (six[0] == state_color) {
                            if (six[5] == 0 || six[5] == 10 || six[3] == 0 || six[3] == 10 || six[2] == 0 || six[2] == 10 || six[4] == 0 || six[4] == 10)
                                value -= 720;

                        } else if (six[5] == state_color) value -= 720;
                        else if (six[0] == six[5] && six[5] == -state_color) value -= 4320;
                        break;
                    case 3:
                        if (countm == 0 && six[1] == six[2] && six[2] == six[3] && six[3] == -state_color) value -= 720;
                        if (countm == 0 && six[2] == six[3] && six[3] == six[4] && six[4] == -state_color) value -= 720;
                        else if (countm == 0 && six[1] == six[2] && six[2] == six[4] && six[4] == -state_color)
                            value -= 720;
                        else if (countm == 0 && six[1] == six[3] && six[3] == six[4] && six[4] == -state_color)
                            value -= 720;
                        break;
                    case 2:
                        if (countm == 0 && six[2] == six[3] && six[3] == -state_color) value -= 120;
                        else if (countm == 0 && six[2] == six[4] && six[4] == -state_color) value -= 120;
                        else if (countm == 0 && six[1] == six[3] && six[3] == -state_color) value -= 120;
                        break;
                    case 1:
                        if (countm == 0 && six[3] == -state_color) value -= 20;
                        if (countm == 0 && six[2] == -state_color) value -= 20;

                }
                countm = 0;
                county = 0;
            }
        }

        //��ɨ��
        for (int i = 0; i < 19; i++) {
            for (int j = 0; j < 14; j++) {
                for (int k = 0; k < 6; k++) {
                    if (mind[j + k][i] == 0 || mind[j + k][i] == 10) space++;
                    if (mind[j + k][i] == state_color) countm++;
                    if (mind[j + k][i] == -state_color) county++;
                    six[k] = mind[j + k][i];
                }

                if (space == 5) continue;
                if (countm > 1 && county > 1) continue;
                switch (countm) {
                    case 5:
                        value += 100000;
                        break;
                    case 4:
                        if (six[0] == -state_color) {
                            if (six[5] == 0 || six[5] == 10 || six[3] == 0 || six[3] == 10 || six[2] == 0 || six[2] == 10 || six[4] == 0 || six[4] == 10)
                                value += 720;

                        } else if (six[5] == -state_color) value += 720;
                        else if (six[0] == six[5] && six[5] == state_color) value += 4320;
                        break;
                    case 3:
                        if (county == 0 && six[1] == six[2] && six[2] == six[3] && six[3] == state_color) value += 720;
                        if (county == 0 && six[2] == six[3] && six[3] == six[4] && six[4] == state_color) value += 720;
                        else if (county == 0 && six[1] == six[2] && six[2] == six[4] && six[4] == state_color)
                            value += 720;
                        else if (county == 0 && six[1] == six[3] && six[3] == six[4] && six[4] == state_color)
                            value += 720;
                        break;
                    case 2:
                        if (county == 0 && six[2] == six[3] && six[3] == state_color) value += 120;
                        else if (county == 0 && six[2] == six[4] && six[4] == state_color) value += 120;
                        else if (county == 0 && six[1] == six[3] && six[3] == state_color) value += 120;
                        break;
                    case 1:
                        if (county == 0 && six[3] == state_color) value += 20;
                        if (county == 0 && six[2] == state_color) value += 20;
                }

                switch (county) {
                    case 5:
                        value -= 100000;
                        break;
                    case 4:
                        if (six[0] == state_color) {
                            if (six[5] == 0 || six[5] == 10 || six[3] == 0 || six[3] == 10 || six[2] == 0 || six[2] == 10 || six[4] == 0 || six[4] == 10)
                                value -= 720;

                        } else if (six[5] == state_color) value -= 720;
                        else if (six[0] == six[5] && six[5] == -state_color) value -= 4320;
                        break;
                    case 3:
                        if (countm == 0 && six[1] == six[2] && six[2] == six[3] && six[3] == -state_color) value -= 720;
                        if (countm == 0 && six[2] == six[3] && six[3] == six[4] && six[4] == -state_color) value -= 720;
                        else if (countm == 0 && six[1] == six[2] && six[2] == six[4] && six[4] == -state_color)
                            value -= 720;
                        else if (countm == 0 && six[1] == six[3] && six[3] == six[4] && six[4] == -state_color)
                            value -= 720;
                        break;
                    case 2:
                        if (countm == 0 && six[2] == six[3] && six[3] == -state_color) value -= 120;
                        else if (countm == 0 && six[2] == six[4] && six[4] == -state_color) value -= 120;
                        else if (countm == 0 && six[1] == six[3] && six[3] == -state_color) value -= 120;
                        break;
                    case 1:
                        if (countm == 0 && six[3] == -state_color) value -= 20;
                        if (countm == 0 && six[2] == -state_color) value -= 20;
                }
                countm = 0;
                county = 0;
            }
        }
        //��б����
        for (int i = 5; i < 19; i++) {
            for (int j = 0; j < 14; j++) {

                for (int k = 0; k < 6; k++) {


                    if (mind[i - k][j + k] == 0 || mind[i - k][j + k] == 10) space++;
                    if (mind[i - k][j + k] == state_color) countm++;
                    if (mind[i - k][j + k] == -state_color) county++;
                    six[k] = mind[i - k][j + k];


                }

                if (space == 5) continue;
                if (countm > 1 && county > 1) continue;
                switch (countm) {
                    case 5:
                        value += 100000;
                        break;
                    case 4:
                        if (six[0] == -state_color) {
                            if (six[5] == 0 || six[5] == 10 || six[3] == 0 || six[3] == 10 || six[2] == 0 || six[2] == 10 || six[4] == 0 || six[4] == 10)
                                value += 720;

                        } else if (six[5] == -state_color) value += 720;
                        else if (six[0] == six[5] && six[5] == state_color) value += 4320;
                        break;
                    case 3:
                        if (county == 0 && six[1] == six[2] && six[2] == six[3] && six[3] == state_color) value += 720;
                        if (county == 0 && six[2] == six[3] && six[3] == six[4] && six[4] == state_color) value += 720;
                        else if (county == 0 && six[1] == six[2] && six[2] == six[4] && six[4] == state_color)
                            value += 720;
                        else if (county == 0 && six[1] == six[3] && six[3] == six[4] && six[4] == state_color)
                            value += 720;
                        break;
                    case 2:
                        if (county == 0 && six[2] == six[3] && six[3] == state_color) value += 120;
                        else if (county == 0 && six[2] == six[4] && six[4] == state_color) value += 120;
                        else if (county == 0 && six[1] == six[3] && six[3] == state_color) value += 120;
                        break;
                    case 1:
                        if (county == 0 && six[3] == state_color) value += 20;
                        if (county == 0 && six[2] == state_color) value += 20;
                }
                //�Է�����
                switch (county) {
                    case 5:
                        value -= 100000;
                        break;
                    case 4:
                        if (six[0] == state_color) {
                            if (six[5] == 0 || six[5] == 10 || six[3] == 0 || six[3] == 10 || six[2] == 0 || six[2] == 10 || six[4] == 0 || six[4] == 10)
                                value -= 720;

                        } else if (six[5] == state_color) value -= 720;
                        else if (six[0] == six[5] && six[5] == -state_color) value -= 4320;
                        break;
                    case 3:
                        if (countm == 0 && six[1] == six[2] && six[2] == six[3] && six[3] == -state_color) value -= 720;
                        if (countm == 0 && six[2] == six[3] && six[3] == six[4] && six[4] == -state_color) value -= 720;
                        else if (countm == 0 && six[1] == six[2] && six[2] == six[4] && six[4] == -state_color)
                            value -= 720;
                        else if (countm == 0 && six[1] == six[3] && six[3] == six[4] && six[4] == -state_color)
                            value -= 720;
                        break;
                    case 2:
                        if (countm == 0 && six[2] == six[3] && six[3] == -state_color) value -= 120;
                        else if (countm == 0 && six[2] == six[4] && six[4] == -state_color) value -= 120;
                        else if (countm == 0 && six[1] == six[3] && six[3] == -state_color) value -= 120;
                        break;
                    case 1:
                        if (countm == 0 && six[3] == -state_color) value -= 20;
                        if (countm == 0 && six[2] == -state_color) value -= 20;
                }
                countm = 0;
                county = 0;

            }
        }
        //��б����
        for (int i = 0; i < 14; i++) {
            for (int j = 5; j < 19; j++) {

                for (int k = 0; k < 6; k++) {


                    if (mind[i + k][j - k] == 0 || mind[i + k][j - k] == 10) space++;
                    if (mind[i + k][j - k] == state_color) countm++;
                    if (mind[i + k][j - k] == -state_color) county++;
                    six[k] = mind[i + k][j - k];

                }

                if (space == 5) continue;
                if (countm > 1 && county > 1) continue;
                switch (countm) {
                    case 5:
                        value += 100000;
                        break;
                    case 4:
                        if (six[0] == -state_color) {
                            if (six[5] == 0 || six[5] == 10 || six[3] == -0 || six[3] == 10 || six[2] == 0 || six[2] == 10 || six[4] == 0 || six[4] == 10)
                                value += 720;

                        } else if (six[5] == -state_color) value += 720;
                        else if (six[0] == six[5] && six[5] == state_color) value += 4320;
                        break;
                    case 3:
                        if (county == 0 && six[1] == six[2] && six[2] == six[3] && six[3] == state_color) value += 720;
                        if (county == 0 && six[2] == six[3] && six[3] == six[4] && six[4] == state_color) value += 720;
                        else if (county == 0 && six[1] == six[2] && six[2] == six[4] && six[4] == state_color)
                            value += 720;
                        else if (county == 0 && six[1] == six[3] && six[3] == six[4] && six[4] == state_color)
                            value += 720;
                        break;
                    case 2:
                        if (county == 0 && six[2] == six[3] && six[3] == state_color) value += 120;
                        else if (county == 0 && six[2] == six[4] && six[4] == state_color) value += 120;
                        else if (county == 0 && six[1] == six[3] && six[3] == state_color) value += 120;
                        break;
                    case 1:
                        if (county == 0 && six[3] == state_color) value += 20;
                        if (county == 0 && six[2] == state_color) value += 20;
                }
                //�Է�����
                switch (county) {
                    case 5:
                        value -= 100000;
                        break;
                    case 4:
                        if (six[0] == state_color) {
                            if (six[5] == 0 || six[5] == 10 || six[3] == 0 || six[3] == 10 || six[2] == 0 || six[2] == 10 || six[4] == 0 || six[4] == 10)
                                value -= 720;

                        } else if (six[5] == state_color) value -= 720;
                        else if (six[0] == six[5] && six[5] == -state_color) value -= 4320;
                        break;
                    case 3:
                        if (countm == 0 && six[1] == six[2] && six[2] == six[3] && six[3] == -state_color) value -= 720;
                        if (countm == 0 && six[2] == six[3] && six[3] == six[4] && six[4] == -state_color) value -= 720;
                        else if (countm == 0 && six[1] == six[2] && six[2] == six[4] && six[4] == -state_color)
                            value -= 720;
                        else if (countm == 0 && six[1] == six[3] && six[3] == six[4] && six[4] == -state_color)
                            value -= 720;
                        break;
                    case 2:
                        if (countm == 0 && six[2] == six[3] && six[3] == -state_color) value -= 120;
                        else if (countm == 0 && six[2] == six[4] && six[4] == -state_color) value -= 120;
                        else if (countm == 0 && six[1] == six[3] && six[3] == -state_color) value -= 120;
                        break;
                    case 1:
                        if (countm == 0 && six[3] == -state_color) value -= 20;
                        if (countm == 0 && six[2] == -state_color) value -= 20;
                }
                countm = 0;
                county = 0;

            }
        }
        return value;

    }





    public Node makemove(Node n)
    {
        for(int i=0;i<19;i++)
            for(int j=0;j<19;j++)
            {
                if(Node.board[i][j]==10)
                {  Node n2=new Node(i,j);
                    n2.min=-n.min;

                    Node.board[i][j]=n2.min* state_color;

                    n2.deep=n.deep+1;

                    return n2;
                }
            }
        return null;
    }
    public void unmakemove(Node n)
    {

        Node n1=n.son;
        while(n1!=null) {
            Node.board[n1.x][n1.y] = 0;
            n1=n1.brother;
        }
    }
    public int AlphaBeta(Node nPly)
    {
        int Evaluation=Evaluation(Node.board);

        if(Evaluation>100000)
            return Evaluation;//ʤ���ѷ֣����ع���ֵ
        if(nPly.deep>=5)
        {
            return Evaluation;
        }//Ҷ�ӽڵ㷵�ع���ֵ
        if(nPly.min!= state_color)//�˾������жϵ�ǰ�ڵ��Ǻ��ֽڵ�
        {
            while(true)//��ÿ���߷�
            {
                Node n1=makemove(nPly);

                if(n1==null){break;}if(n1.deep<5) Node.initial(Node.board);
                if(nPly.son==null){nPly.son=n1;n1.father=nPly;}
                else{
                    Node n2;
                    n2=nPly.son;
                    while(n2.brother!=null)
                    {

                        n2=n2.brother;

                    }
                    n2.brother=n1;
                    n1.father=nPly;
                }
                nPly.score=AlphaBeta(n1);
                unmakemove(nPly);//������������

                if(nPly.deep>1)
                {if(nPly.score<nPly.Beta)
                {
                    nPly.Beta=nPly.score;
                    if(nPly.father.Alpha>=nPly.Beta)
                    {return nPly.father.Alpha;}//��ֽ
                }}



            } if(nPly.deep>0){unmakemove(nPly.father);Node.initial(Node.board);}return nPly.Beta;//������Сֵ
        }

        else
        {//ȡ����ֵ�ڵ�


            while(true)//��ÿ���߷�
            {
                Node n1=makemove(nPly);

                if(n1==null)break;if(n1.deep<5)Node.initial(Node.board);
                if(nPly.son==null){nPly.son=n1;n1.father=nPly;}
                else{

                    Node n2;
                    n2=nPly.son;
                    while(n2.brother!=null)
                    {
                        n2=n2.brother;

                    }
                    n2.brother=n1;
                    n1.father=nPly;
                }
                nPly.score=AlphaBeta(n1);
                unmakemove(nPly);
                if(nPly.deep>1) {
                    if (nPly.score > nPly.Alpha) {
                        nPly.Alpha = nPly.score;
                        if (nPly.Alpha >= nPly.father.Beta)
                        {return nPly.father.Beta;}
                    }
                }
            }if(nPly.deep>0){unmakemove(nPly.father);Node.initial(Node.board);}
            return nPly.Alpha;
        }
    }


}
class test{
    public static void main(String[] args){
        int[][] m=new int[19][19];
        for(int i=0;i<19;i++)
            for(int j=0;j<19;j++)
                m[i][j]=0;
        m[10][10]=1;
        Calculate p1=new Calculate(1);
        int a,b;
        Scanner keyin=new Scanner(System.in);
        while(true)
        {int x,y;
            System.out.println("������x");
            a=keyin.nextInt();
            System.out.println("������y");
            b=keyin.nextInt();
            //p1.see(m);
            m[a][b]=-1;
            Node s=new Node();
            Node.initial(m);
            p1.AlphaBeta(s);
            Node n1;
            int max=0;
            n1=s.son;
            x=0;y=0;
            while(n1!=null) {
                if (max<n1.score) {
                    max=n1.score;
                    x = n1.x;
                    y = n1.y;
                }
                n1 = n1.brother;
            }
            //x=s.x;y=s.y;
            System.out.println("x:"+x+" y:"+y+" "+max);
            m[x][y]=1;

        }}
}
